Apache Commons Compress was derived from various sources, including:

Original BZip2 classes contributed by Keiron Liddle
<keiron@aftexsw.com>, Aftex Software to the Apache Ant project

Original Tar classes from contributors of the Apache Ant project

Original Zip classes from contributors of the Apache Ant project

Original CPIO classes contributed by Markus Kuss and the jRPM project
(jrpm.sourceforge.net)
